#ifndef ADMANAGER_H
#define ADMANAGER_H

#include <vector>
#include <string>
#include <map>
#include "Movie.h"

class AdManager
{
public:
    static void saveAdTimes(const std::string &filename, const std::string &movieName,
                            const std::vector<std::string> &startAds,
                            const std::vector<std::string> &breakAds);

    static std::map<std::string, std::pair<std::vector<std::string>, std::vector<std::string>>>
    loadAdTimes(const std::string &filename);
};

#endif
