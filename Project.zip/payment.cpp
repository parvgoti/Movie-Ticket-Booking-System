#include "Payment.h"
#include <iostream>
#include <fstream>
#include <limits>

using namespace std;

const int MAX_SEATS = 100;

void Payment::pay()
{
    int howpay;
    string a;
    string phone, email, name1;

    int available = MAX_SEATS - getBookedSeats();
    if (available != 0)
    {
        cout << endl;
        cout << "This Tickets are  non-Cancelable" << endl
             << endl;
        cout << "You Wants to Confirm Tickets" << endl;
        cout << "Enter Your Answer in Yes or No : ";
        cin >> a;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (a == "yes" || a == "Yes")
        {
            ofstream out("booking_details.txt", ios::app);

            out << "Movie : " << name << endl;
            out << "Date : " << dates[dayChoice - 1] << endl;
            out << "Time : " << times[timeChoice - 1] << endl;
            out << "Base price : " << basePrice << endl;
            out << "GST : " << gst << endl;
            out << "Tickets : " << numAdults << endl;
            out << "Total Price : " << totalPrice << endl;

            cout << endl;
            cout << "Enter Your Name : ";
            getline(cin, name1);
            cout << "Enter Your Phone Number : ";
            getline(cin, phone);
            cout << "Enter Your Email ID : ";
            getline(cin, email);
            ofstream outfile("customer_details.txt", ios::app);
            outfile << endl;
            outfile << "Customer Name : " << name1 << endl;
            outfile << "Phone number : " << phone << endl;
            outfile << "Email ID : " << email << endl;
            outfile << endl;

            cout << endl;
            cout << "You are Registered With Us" << endl;
            cout << endl;

            cout << "How You Pay Your Bill " << endl;
            cout << endl;
            cout << " 1 For Pay In Cash" << endl;
            cout << " 2 For UPI App" << endl;
            cout << " 3 For Net Banking" << endl;
            cout << " 4 For Debit/Credit Card" << endl;
            cout << " 5 For Digital Wallet" << endl;
            cout << endl;
            cout << "Enter mode of Payment : ";
            cin >> howpay;
            cout << endl;
            cout << " Payment Successfully Done" << endl
                 << endl;
            cout << "Your Ticket Sent On Your Email" << endl
                 << endl;
            cout << "_____HAVE A NICE DAY_____" << endl;
        }
        else if (a == "no" || a == "No")
        {
            cout << "Thanks For Visit";
            return;
        }
        else
        {
            cout << "Invalid input! Please enter 'yes' or 'no'." << endl;
            return pay();
        }

        ofstream outfile("booking_details.txt", ios::app);

        outfile << "Customer Name : " << name1 << endl;

        if (howpay == 1)
        {
            outfile << "Mode of Payment : Pay In Cash" << endl;
        }
        else if (howpay == 2)
        {
            outfile << "Mode of Payment : UPI App" << endl;
        }
        else if (howpay == 3)
        {
            outfile << "Mode of Payment : Net Banking" << endl;
        }
        else if (howpay == 4)
        {
            outfile << "Mode of Payment : Debit/Credit Card" << endl;
        }
        else if (howpay == 5)
        {
            outfile << "Mode of Payment : Digital Wallet" << endl;
        }
        outfile << endl;
    }
}

Payment::Payment(const Movie &movie) : Movie(movie)
{
}
