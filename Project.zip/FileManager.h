#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <vector>
#include <string>
#include "Movie.h"

class FileManager {
public:
    static std::vector<Movie> loadMovies(const std::string &filename);
    static void saveMovies(const std::string &filename, const std::vector<Movie> &movies);
};

#endif
