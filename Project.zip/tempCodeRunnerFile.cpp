#include <vector>
#include <string>

struct Movie {
	std::string title;
	int year;
};

int main() {
	std::vector<Movie> movies;
	movies.emplace_back(Movie{"Inception", 2010}); // INSIDE main function
	return 0;
}
