#include "FileManager.h"
#include "Movie.h"
#include <fstream>
#include <vector>
#include <string>
using namespace std;

vector<Movie> FileManager::loadMovies(const string &filename)
{
    ifstream file(filename);
    vector<Movie> movies;

    string name;
    while (getline(file, name))
    {
        string dates[5],
            times[5], prices[5];
        for (int i = 0; i < 5; ++i)
            getline(file, dates[i]);
        for (int i = 0; i < 5; ++i)
            getline(file, times[i]);
        for (int i = 0; i < 5; ++i)
            getline(file, prices[i]);
        static int screenNo = 0;
        movies.emplace_back(++screenNo, name, dates, times, prices);
    }
    return movies;
}

void FileManager::saveMovies(const string &filename, const vector<Movie> &movies)
{
    ofstream file(filename);
    for (const Movie &m : movies)
    {
        file << m.getName() << endl;
        for (int i = 0; i < 5; ++i)
            file << m.getDate(i) << endl;
        for (int i = 0; i < 5; ++i)
            file << m.getTime(i) << endl;
        for (int i = 0; i < 5; ++i)
            file << m.getPrice(i) << endl;
    }
    file.close();
}
