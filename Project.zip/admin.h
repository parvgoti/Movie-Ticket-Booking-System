#ifndef ADMIN_H
#define ADMIN_H

#include <string>
#include <vector>
#include "Movie.h"

using namespace std;

class Admin
{
public:
    void adminLogin(vector<Movie> &movies);
    void editMovieNames(vector<Movie> &movies);
    void editMovieDates(vector<Movie> &movies);
    void editMovieTimes(vector<Movie> &movies);
    void editMoviePrices(vector<Movie> &movies);

    void showCustomerDetails();
    void showTotalEarnings();
    void showMovieWiseSummary();
    void showDateWiseSummary();

    void editAdvertisementTimes(std::vector<Movie> &movies);
    void showAdvertisementTimes();
    void editAdvertisementPrices(std::vector<Movie> &movies);
    void showAdEarnings();

private:
    bool authenticate();
};
#endif
