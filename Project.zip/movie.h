#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include <vector>

using namespace std;

class Movie
{
protected:
    int screenNo;
    string name;
    string dates[5];
    string times[5];
    string prices[5];
    int dayChoice, timeChoice, numAdults;
    float basePrice, gst, totalPrice;

public:
    Movie(int screen, const string &name, const string d[5], const string t[5], const string p[5]);
    void setName(const std::string &newName);
    void setDate(int index, const std::string &newDate);
    void setTime(int index, const std::string &newTime);
    void setPrice(int index, const std::string &newPrice);

    string getShowID() const;
    int getBookedSeats() const;
    void updateBookedSeats(int additional);

    void selectDate();
    void selectTime();
    void showPrice();
    void bookTickets();
    void printReceipt();

    float getTotalPrice() const;
    float getBasePrice() const;
    float getGST() const;
    string getName() const;
    string getDate(int) const;
    string getTime(int) const;
    string getPrice(int) const;
    int getNumTickets() const;

protected:
    float extractPrice(const string &priceStr) const;
};

#endif
