// AdvertisementAgent.h
#ifndef ADVERTISEMENT_AGENT_H
#define ADVERTISEMENT_AGENT_H

#include <string>
#include <vector>

class AdvertisementAgent {
public:
    void bookAdSlot();  // Main function to handle ad slot booking
private:
    std::string normalizeTime(const std::string& timeStr);
};

#endif
