#include <iostream>
#include <vector>
#include "Payment.h"
#include "Admin.h"
#include "AdvertisementAgent.h"
#include "FileManager.h"

using namespace std;

int main()
{
    vector<Movie> movies = FileManager::loadMovies("movie_data.txt");

    if (movies.empty())
    {
        cout << " No valid movie data found. Please check movie_data.txt\n";
        return 1;
    }

    cout << "\n=== Welcome to Movie Booking System ===\n";
    cout << "1. Admin\n";
    cout << "2. User\n";
    cout << "3. Advertisement Agent\n";
    cout << "4. Exit\n";
    cout << "Enter your role: ";
    string choice;
    getline(cin, choice);

    if (choice == "1")
    {
        Admin admin;
        admin.adminLogin(movies);
    }
    else if (choice == "2")
    {
        cout << "\nSelect a Movie:\n";
        for (int i = 0; i < movies.size(); ++i)
        {
            cout << i + 1 << ". " << movies[i].getName() << "\n";
        }

        int movieChoice;
        cout << "Enter choice (1-" << movies.size() << "): ";
        cin >> movieChoice;
        cin.ignore();

        if (movieChoice >= 1 && movieChoice <= movies.size())
        {
            Payment selectedMovie = movies[movieChoice - 1];
            selectedMovie.selectDate();
            selectedMovie.selectTime();
            selectedMovie.showPrice();
            selectedMovie.bookTickets();
            selectedMovie.printReceipt();
            selectedMovie.pay();
            cout << endl
                 << "_____Thanks For Your Ticket Booking_____";
        }
        else
        {
            cout << "Invalid movie selection.\n";
        }
        
    }
    else if (choice == "3")
    {
        AdvertisementAgent agent;
        agent.bookAdSlot();
    }
    else if (choice == "4")
    {
        cout << "Exiting the application.\n";
        return 0;
    }
    else
    {
        cout << "Invalid input. Try again.\n";
    }
}
// g++ main.cpp Movie.cpp Admin.cpp Payment.cpp AdvertisementAgent.cpp FileManager.cpp Admanager.cpp -o MovieApp
