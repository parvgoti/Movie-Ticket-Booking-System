#ifndef PAYMENT_H
#define PAYMENT_H

#include "Movie.h"
#include <string>

class Payment : public Movie {
public:
    using Movie::Movie;

    void pay();
    Payment(const Movie& movie);
};

#endif
