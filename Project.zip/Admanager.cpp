#include "AdManager.h"
#include <fstream>
#include <iostream>
#include <map>

using namespace std;

void AdManager::saveAdTimes(const string &filename, const string &movieName,
                            const vector<string> &startAds, const vector<string> &breakAds)
{
    ofstream outFile(filename, ios::app);
    if (!outFile)
    {
        cerr << " Could not open " << filename << " for writing.\n";
        return;
    }

    outFile << movieName << "\n";
    outFile << "START\n";
    for (const string &time : startAds)
    {
        outFile << time << "\n";
    }
    outFile << "BREAK\n";
    for (const string &time : breakAds)
    {
        outFile << time << "\n";
    }
    outFile.close();

    cout << " Ad times for \"" << movieName << "\" saved to " << filename << "\n";
}

map<string, pair<vector<string>, vector<string>>> AdManager::loadAdTimes(const string &filename)
{
    map<string, pair<vector<string>, vector<string>>> adData;
    ifstream inFile(filename);
    if (!inFile)
    {
        cerr << " Could not open " << filename << " for reading.\n";
        return adData;
    }

    string line;
    while (getline(inFile, line))
    {
        string movieName = line;
        vector<string> startAds, breakAds;

        getline(inFile, line);
        for (int i = 0; i < 5; ++i)
        {
            string time;
            if (getline(inFile, time))
                startAds.push_back(time);
        }

        getline(inFile, line);
        for (int i = 0; i < 5; ++i)
        {
            string time;
            if (getline(inFile, time))
                breakAds.push_back(time);
        }

        adData[movieName] = {startAds, breakAds};
    }

    inFile.close();
    return adData;
}
