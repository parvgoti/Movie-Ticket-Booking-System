#include "Movie.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <limits>
using namespace std;

Movie::Movie(int screen, const string &movieName, const string d[5], const string t[5], const string p[5])
    : screenNo(screen), name(movieName), dayChoice(0), timeChoice(0), numAdults(0), basePrice(0), gst(0), totalPrice(0)
{
    for (int i = 0; i < 5; ++i)
    {
        dates[i] = d[i];
        times[i] = t[i];
        prices[i] = p[i];
    }
}

string Movie::getShowID() const
{
    return "m" + to_string(screenNo) + "_d" + to_string(dayChoice) + "_t" + to_string(timeChoice) + ".txt";
}

int Movie::getBookedSeats() const
{
    ifstream inFile(getShowID());
    int booked = 0;
    if (inFile.is_open())
    {
        inFile >> booked;
        inFile.close();
    }
    return booked;
}

void Movie::updateBookedSeats(int additional)
{
    int booked = getBookedSeats() + additional;
    ofstream outFile(getShowID());
    if (outFile.is_open())
    {
        outFile << booked;
        outFile.close();
    }
}

void Movie::selectDate()
{
    cout << "\nChoose Date for " << name << endl;

    time_t now = time(0);
    tm *ltm = localtime(&now);
    int todayDay = ltm->tm_mday;
    int todayMonth = ltm->tm_mon + 1;
    int todayYear = ltm->tm_year + 1900;

    bool shown = false;

    for (int i = 0; i < 5; ++i)
    {
        if (dates[i].empty())
            continue;

        int d, m, y;
        char sep;
        stringstream ss(dates[i]);
        ss >> d >> sep >> m >> sep >> y;

        if (y > todayYear || (y == todayYear && m > todayMonth) ||
            (y == todayYear && m == todayMonth && d >= todayDay))
        {
            cout << " " << (i + 1) << " For " << dates[i] << endl;
            shown = true;
        }
    }

    if (!shown)
    {
        cout << "No valid dates available (only past dates)." << endl;
        return;
    }

    while (true)
    {
        cout << "Enter Date Choice (1-5): ";
        string input;
        getline(cin, input);
        stringstream ss(input);
        if (ss >> dayChoice && !(ss >> input) && dayChoice >= 1 && dayChoice <= 5)
        {
            int d, m, y;
            char sep;
            stringstream dateSS(dates[dayChoice - 1]);
            dateSS >> d >> sep >> m >> sep >> y;

            if (y > todayYear || (y == todayYear && m > todayMonth) ||
                (y == todayYear && m == todayMonth && d >= todayDay))
            {
                break;
            }
        }
        cout << "Invalid or past date. Try again." << endl;
    }
}

void Movie::selectTime()
{
    cout << "\nChoose Time Slot for " << name << endl;

    // Get selected date
    string selectedDateStr = dates[dayChoice - 1];
    int selDay, selMonth, selYear;
    char sep;
    stringstream ss(selectedDateStr);
    ss >> selDay >> sep >> selMonth >> sep >> selYear;

    // Get current date and time
    time_t now = time(0);
    tm *ltm = localtime(&now);
    int todayDay = ltm->tm_mday;
    int todayMonth = ltm->tm_mon + 1;
    int todayYear = ltm->tm_year + 1900;

    char currentTimeStr[10];
    strftime(currentTimeStr, sizeof(currentTimeStr), "%I:%M %p", ltm);
    string currentTime(currentTimeStr);

    auto toMinutes = [](const string &timeStr) -> int
    {
        int hour, min;
        char colon;
        string ampm;
        stringstream ss(timeStr);
        ss >> hour >> colon >> min >> ampm;
        if (ampm == "PM" && hour != 12)
            hour += 12;
        if (ampm == "AM" && hour == 12)
            hour = 0;
        return hour * 60 + min;
    };

    int currentMins = toMinutes(currentTime);

    bool shown = false;
    for (int i = 0; i < 5; ++i)
    {
        if (!times[i].empty())
        {
            int slotMins = toMinutes(times[i]);
            // If selected date is today, only show future slots
            if (selYear == todayYear && selMonth == todayMonth && selDay == todayDay)
            {
                if (slotMins > currentMins)
                {
                    cout << " " << (i + 1) << " For " << times[i] << endl;
                    shown = true;
                }
                else
                {
                    cout << " " << (i + 1) << " [Time Expired]" << endl;
                }
            }
            // For future dates, show all slots
            else if (selYear > todayYear || (selYear == todayYear && selMonth > todayMonth) ||
                     (selYear == todayYear && selMonth == todayMonth && selDay > todayDay))
            {
                cout << " " << (i + 1) << " For " << times[i] << endl;
                shown = true;
            }
            else
            {
                cout << " " << (i + 1) << " [Time Expired]" << endl;
            }
        }
        else
        {
            cout << " " << (i + 1) << " [No Slot Available]" << endl;
        }
    }

    if (!shown)
    {
        cout << "No valid time slots remaining for selected date." << endl;
        return;
    }

    while (true)
    {
        cout << "Enter Time Choice (1-5): ";
        string input;
        getline(cin, input);
        stringstream ss(input);
        if (ss >> timeChoice && !(ss >> input) && timeChoice >= 1 && timeChoice <= 5)
        {
            int slotMins = toMinutes(times[timeChoice - 1]);
            // For today, only allow future slots
            if (selYear == todayYear && selMonth == todayMonth && selDay == todayDay)
            {
                if (slotMins > currentMins)
                    break;
            }
            // For future dates, allow all slots
            else if (selYear > todayYear || (selYear == todayYear && selMonth > todayMonth) ||
                     (selYear == todayYear && selMonth == todayMonth && selDay > todayDay))
            {
                break;
            }
        }
        cout << "Invalid or expired time. Try again." << endl;
    }
}

void Movie::showPrice()
{
    if (getBookedSeats() >= 100)
    {
        cout << "Sorry! This show is full." << endl;
        return;
    }
    cout << endl
         << "Ticket Price for selected slot: " << prices[timeChoice - 1] << endl;
}

void Movie::bookTickets()
{
    int available = 100 - getBookedSeats();
    if (available <= 0)
    {
        cout << "Sorry! No seats available." << endl;
        return;
    }

    cout << "Available Seats: " << available << endl;
    cout << "How Many Tickets You Want To Book: ";
    cin >> numAdults;
    cin.ignore();

    if (numAdults > available)
    {
        cout << "Only " << available << " seats left. Try again." << endl;
        bookTickets();
        return;
    }

    float price = extractPrice(prices[timeChoice - 1]);
    basePrice = numAdults * price;
    gst = basePrice * 0.18f;
    totalPrice = basePrice + gst;

    updateBookedSeats(numAdults);
    cout << "Total Price with GST: " << totalPrice << " INR" << endl;
}

void Movie::printReceipt()
{
    cout << endl
         << "Please Confirm All The Detials " << endl;
    cout << endl;
    cout << "Screen No: " << screenNo << endl;
    cout << "Movie : " << name << endl;
    cout << "Date : " << dates[dayChoice - 1] << endl;
    cout << "Time : " << times[timeChoice - 1] << endl;
    cout << "Base price : " << basePrice << endl;
    cout << "GSt : " << gst << endl;
    cout << "Tickets : " << numAdults << endl;
    cout << "Total : " << totalPrice << " INR" << endl;
}

float Movie::extractPrice(const string &priceStr) const
{
    string digits;
    for (char c : priceStr)
    {
        if (isdigit(c) || c == '.')
            digits += c;
        else
            break;
    }
    return digits.empty() ? 0.0f : stof(digits);
}

float Movie::getTotalPrice() const { return totalPrice; }
float Movie::getBasePrice() const { return basePrice; }
float Movie::getGST() const { return gst; }
string Movie::getName() const
{
    return name;
}

string Movie::getDate(int index) const
{
    return (index >= 0 && index < 5) ? dates[index] : "";
}

string Movie::getTime(int index) const
{
    return (index >= 0 && index < 5) ? times[index] : "";
}

string Movie::getPrice(int index) const
{
    return (index >= 0 && index < 5) ? prices[index] : "";
}

int Movie::getNumTickets() const { return numAdults; }

void Movie::setName(const string &newName) { name = newName; }
void Movie::setDate(int index, const string &newDate)
{
    if (index >= 0 && index < 5)
        dates[index] = newDate;
}
void Movie::setTime(int index, const string &newTime)
{
    if (index >= 0 && index < 5)
        times[index] = newTime;
}
void Movie::setPrice(int index, const string &newPrice)
{
    if (index >= 0 && index < 5)
        prices[index] = newPrice;
}