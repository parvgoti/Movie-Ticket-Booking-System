#include "AdvertisementAgent.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

void AdvertisementAgent::bookAdSlot()
{
    string agentName, companyName;
    cout << "Enter Your Name: ";
    getline(cin, agentName);
    cout << "Enter Your Company Name: ";
    getline(cin, companyName);

    vector<string> movieList = {"Kannappa", "F1: The Movie", "Sitaare Zameen Par", "Jalebi Rocks", "Maa"};
    for (int i = 0; i < movieList.size(); ++i)
    {
        cout << i + 1 << ". " << movieList[i] << endl;
    }

    int movieChoice;
    cout << "Choose Movie (1-5): ";
    cin >> movieChoice;
    cin.ignore();

    if (movieChoice < 1 || movieChoice > 5)
    {
        cout << "Invalid movie choice.\n";
        return;
    }

    vector<string> showTimes = {"9:00 AM", "12:00 PM", "4:00 PM", "8:00 PM", "12:00 AM"};
    cout << "\nShow Times:\n";
    for (int i = 0; i < showTimes.size(); ++i)
    {
        cout << " " << i + 1 << ". " << showTimes[i] << endl;
    }

    int timeSlot;
    cout << "Choose Time Slot (1-5): ";
    cin >> timeSlot;
    cin.ignore();

    if (timeSlot < 1 || timeSlot > 5)
    {
        cout << "Invalid time slot.\n";
        return;
    }

    string slotType;
    while (true)
    {
        cout << "Select Slot Type (start/break): ";
        getline(cin, slotType);
        transform(slotType.begin(), slotType.end(), slotType.begin(), ::tolower);
        if (slotType == "start" || slotType == "break")
            break;
        cout << "Invalid input. Please enter 'start' or 'break'.\n";
    }

    stringstream key;
    key << "M" << movieChoice << "-T" << timeSlot << "-" << slotType;

    ifstream bookingCheck("ADBooking_details.txt");
    string line;
    while (getline(bookingCheck, line))
    {
        if (line == key.str())
        {
            cout << "\n This slot is already booked. Please choose a different slot.\n";
            return;
        }
    }
    bookingCheck.close();

    // Payment options
    double basePrice = (slotType == "start") ? 150000 : 80000;
    double gst = basePrice * 0.18;
    double total = basePrice + gst;

    cout << "\n Ad Slot Price: " << basePrice << " INR";
    cout << "\nGST (18%): " << gst << " INR";
    cout << "\nTotal Payable Amount: " << total << " INR\n";

    cout << "\nSelect Payment Method:\n";
    cout << " 1. UPI\n";
    cout << " 2. Debit/Credit Card\n";
    cout << " 3. Net Banking\n";
    cout << " 4. Digital Wallet\n";
    cout << "Choose option: ";
    int payOption;
    cin >> payOption;
    cin.ignore();

    string method;
    switch (payOption)
    {
    case 1:
        method = "UPI";
        break;
    case 2:
        method = "Card";
        break;
    case 3:
        method = "Net Banking";
        break;
    case 4:
        method = "Digital Wallet";
        break;
    }
    ofstream book("ADBooking_details.txt", ios::app);
    book << "Company Name : " << companyName << endl;
    book << "Agent Name : " << agentName << endl;
    book << "Movie: " << movieList[movieChoice - 1] << endl;
    book << "Show Time: " << showTimes[timeSlot - 1] << endl;
    book << "Ad Slot Type: " << slotType << endl;
    book << "Ad Price: " << total << endl;
    book << "Mode of Payment: " << method << endl;
    book << "--------------------------" << endl;
    book.close();
    book << "Payment Method: " << method << " | Amount: " << total << " INR\n";
    book.close();

    cout << "\n Ad slot booked and payment recorded successfully!\n";
    cout << "Movie: " << movieList[movieChoice - 1] << "\n";
    cout << "Show Time: " << showTimes[timeSlot - 1] << "\n";
    cout << "Slot Type: " << slotType << "\n";
    cout << "Ad Price: " << total << endl;
    cout << "Paid via: " << method << "\n";
}
