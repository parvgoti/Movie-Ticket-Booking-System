#include "Admin.h"
#include "AdManager.h"
#include "FileManager.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>
#include <map>
#include <iomanip>
using namespace std;

string name;
void setName(const string &n) { name = n; }
void setDate(int, const string &) {}
void setTimeSlot(int, const string &) {}
void setPriceSlot(int, const string &) {}

bool Admin::authenticate()
{
    string id, pass;
    cout << "Enter Admin ID: ";
    getline(cin, id);
    cout << "Enter Password: ";
    getline(cin, pass);
    return (id == "admin1" && pass == "parv");
}

void Admin::showAdvertisementTimes()
{
    auto adMap = AdManager::loadAdTimes("advertisement_times.txt");

    string selectedMovie;
    cout << "Enter movie name to view ad times (case-sensitive): ";
    getline(cin, selectedMovie);

    if (adMap.find(selectedMovie) != adMap.end())
    {
        auto adPair = adMap[selectedMovie];
        auto start = adPair.first;
        auto brk = adPair.second;

        cout << "\n--- Advertisement Times for \"" << selectedMovie << "\" ---\n";

        cout << "START Ad Slots:\n";
        for (int i = 0; i < start.size(); ++i)
        {
            cout << "  Slot " << (i + 1) << ": " << start[i] << "\n";
        }

        cout << "BREAK Ad Slots:\n";
        for (int i = 0; i < brk.size(); ++i)
        {
            cout << "  Slot " << (i + 1) << ": " << brk[i] << "\n";
        }
    }
    else
    {
        cout << " No ad times found for movie: " << selectedMovie << "\n";
    }
}

void Admin::adminLogin(vector<Movie> &movies)
{
    if (!authenticate())
    {
        cout << "Access Denied.\n";
        return;
    }
    cout << "\n--- Admin Panel ---\n";
    cout << "1. Edit Movie Names\n";
    cout << "2. Edit Movie Dates\n";
    cout << "3. Edit Movie Times\n";
    cout << "4. Edit Movie Prices\n";
    cout << "5. Show Customer Details\n";
    cout << "6. Show Total Earnings\n";
    cout << "7. Show Movie-wise Summary\n";
    cout << "8. Show Date-wise Booking\n";
    cout << "9. Edit Advertisement Times\n";
    cout << "10. Edit Advertisement Prices\n";
    cout << "11. Show Advertisement Earnings\n";
    cout << "12. Exit\n";

    int choice;
    cout << "Enter choice: ";
    cin >> choice;
    cin.ignore();

    switch (choice)
    {
    case 1:
        editMovieNames(movies);
        break;
    case 2:
        editMovieDates(movies);
        break;
    case 3:
        editMovieTimes(movies);
        break;
    case 4:
        editMoviePrices(movies);
        break;
    case 5:
        showCustomerDetails();
        break;
    case 6:
        showTotalEarnings();
        break;
    case 7:
        showMovieWiseSummary();
        break;
    case 8:
        showDateWiseSummary();
        break;
    case 9:
        editAdvertisementTimes(movies);
        break;
    case 10:
        editAdvertisementPrices(movies);
        break;
    case 11:
        showAdEarnings();
        break;
    case 12:
        return;
    default:
        cout << "Invalid option.\n";
        break;
    }
}

void Admin::editMovieNames(vector<Movie> &movies)
{
    cout << "--- Edit Movie Names ---\n";
    for (int i = 0; i < 5; ++i)
    {
        cout << i + 1 << ". " << movies[i].getName() << "\n";
    }

    int choice;
    cout << "Select movie to rename (1-5): ";
    cin >> choice;
    cin.ignore();

    if (choice >= 1 && choice <= 5)
    {
        string newName;
        cout << "Enter new movie name: ";
        getline(cin, newName);
        movies[choice - 1].setName(newName);
        FileManager::saveMovies("movie_data.txt", movies);
        cout << " Movie name updated.\n";
    }
    else
    {
        cout << " Invalid choice.\n";
    }
}

void Admin::editMovieDates(vector<Movie> &movies)
{
    cout << "\n--- Edit Movie Dates ---\n";
    for (int i = 0; i < movies.size(); ++i)
    {
        cout << i + 1 << ". " << movies[i].getName() << "\n";
    }

    int choice;
    cout << "Select a movie to edit (1-" << movies.size() << "): ";
    cin >> choice;
    cin.ignore();

    if (choice < 1 || choice > movies.size())
    {
        cout << "Invalid choice.\n";
        return;
    }

    for (int i = 0; i < 5; ++i)
    {
        string newDate;
        cout << "Enter new date for Slot " << i + 1 << ": ";
        getline(cin, newDate);
        movies[choice - 1].setDate(i, newDate);
    }

    cout << " Dates updated for " << movies[choice - 1].getName() << "\n";
    FileManager::saveMovies("movie_data.txt", movies);
}

void Admin::editMovieTimes(vector<Movie> &movies)
{
    cout << "\n--- Edit Movie Times ---\n";
    for (int i = 0; i < movies.size(); ++i)
    {
        cout << i + 1 << ". " << movies[i].getName() << "\n";
    }

    int choice;
    cout << "Select a movie to edit (1-" << movies.size() << "): ";
    cin >> choice;
    cin.ignore();

    if (choice < 1 || choice > movies.size())
    {
        cout << "Invalid choice.\n";
        return;
    }

    for (int i = 0; i < 5; ++i)
    {
        string newTime;
        cout << "Enter new time slot " << i + 1 << ": ";
        getline(cin, newTime);
        movies[choice - 1].setTime(i, newTime);
    }

    cout << " Times updated for " << movies[choice - 1].getName() << "\n";
    FileManager::saveMovies("movie_data.txt", movies);
}

void Admin::editMoviePrices(vector<Movie> &movies)
{
    cout << "\n--- Edit Movie Price ---\n";
    for (int i = 0; i < movies.size(); ++i)
    {
        cout << i + 1 << ". " << movies[i].getName() << "\n";
    }

    int choice;
    cout << "Select a movie to edit (1-" << movies.size() << "): ";
    cin >> choice;
    cin.ignore();

    if (choice < 1 || choice > movies.size())
    {
        cout << "Invalid choice.\n";
        return;
    }
    cout << "Enter 5 price slots for Movie " << ":\n";
    for (int j = 0; j < 5; ++j)
    {
        string price;
        cout << "New Price " << (j + 1) << ": ";
        getline(cin, price);
        movies[j].setPrice(j, price);
    }
    cout << "Price updated for " << movies[choice - 1].getName() << endl;
}

void Admin::showCustomerDetails()
{
    ifstream infile("customer_details.txt");
    string line;
    cout << "\n--- Customer Details ---\n";
    while (getline(infile, line))
    {
        cout << line << endl;
    }
}

void Admin::showTotalEarnings()
{
    double ticketEarnings = 0;
    double adEarnings = 0;

    ifstream tFile("booking_details.txt");
    string line;
    while (getline(tFile, line))
    {
        if (line.find("Total Price :") != string::npos)
        {
            size_t pos = line.find(":");
            if (pos != string::npos)
            {
                string amountStr = line.substr(pos + 1);
                ticketEarnings += stod(amountStr);
            }
        }
    }
    tFile.close();

    ifstream aFile("ADBooking_details.txt");
    while (getline(aFile, line))
    {
        if (line.find("Ad Price:") != string::npos)
        {
            size_t pos = line.find(":");
            if (pos != string::npos)
            {
                string amountStr = line.substr(pos + 1);
                adEarnings += stod(amountStr);
            }
        }
    }
    aFile.close();

    double total = ticketEarnings + adEarnings;

    cout << "\n Total Earnings from Ticket Booking: " << ticketEarnings << " INR\n";
    cout << " Total Earnings from Ad Booking: " << adEarnings << " INR\n";
    cout << " Combined Total Earnings: " << total << " INR\n";
}

void Admin::showMovieWiseSummary()
{
    map<string, int> ticketCount, adCount;
    map<string, double> ticketEarnings, adEarnings;
    string line, currentMovie, adMovie;

    ifstream tFile("booking_details.txt");
    int currentTicketQty = 0;
    while (getline(tFile, line))
    {
        if (line.find("Movie :") != string::npos)
        {
            currentMovie = line.substr(line.find(":") + 2);
            currentMovie.erase(0, currentMovie.find_first_not_of(" "));
        }
        if (line.find("Tickets :") != string::npos && !currentMovie.empty())
        { 
            int seatCount = stod(line.substr(line.find(":") + 1));
            ticketCount[currentMovie] += seatCount;
        }
        if (line.find("Total Price :") != string::npos && !currentMovie.empty())
        {
            double amt = stod(line.substr(line.find(":") + 1));
            ticketEarnings[currentMovie] += amt;
        }
    }
    tFile.close();

    ifstream aFile("ADBooking_details.txt");
    while (getline(aFile, line))
    {
        if (line.find("Movie:") != string::npos)
        {
            adMovie = line.substr(line.find(":") + 2);
            adMovie.erase(0, adMovie.find_first_not_of(" "));
            adCount[adMovie]++;
        }
        if (line.find("Ad Price:") != string::npos && !adMovie.empty())
        {
            double amt = stod(line.substr(line.find(":") + 1));
            adEarnings[adMovie] += amt;
        }
    }
    aFile.close();

    string searchMovie;
    cout << "\nEnter Movie Name to View Summary (case-sensitive): ";
    getline(cin, searchMovie);

    if (ticketCount.find(searchMovie) != ticketCount.end() || adCount.find(searchMovie) != adCount.end())
    {
        int tickets = ticketCount[searchMovie];
        int ads = adCount[searchMovie];
        double tEarn = ticketEarnings[searchMovie];
        double aEarn = adEarnings[searchMovie];
        double total = tEarn + aEarn;

        cout << "\n--- Movie Summary ---\n";
        cout << " Movie: " << searchMovie << "\n";
        cout << " Tickets Booked : " << tickets << "\n";
        cout << " Ticket Earnings : " << fixed << setprecision(2) << tEarn << " INR\n";
        cout << " Ad Slots Booked : " << ads << "\n";
        cout << " Ad Earnings     : " << fixed << setprecision(2) << aEarn << " INR\n";
        cout << " Total Earnings  : " << fixed << setprecision(2) << total << " INR\n";
        cout << "--------------------------\n";
    }
    else
    {
        cout << "\n No bookings or ads found for movie: " << searchMovie << "\n";
    }
}

void Admin::showDateWiseSummary()
{
    map<string, int> dateCount,ticketCount;
    map<string, double> dateEarnings;

    ifstream file("booking_details.txt");
    string line, currentDate;
    double lastTotal = -1;

    while (getline(file, line))
    {
        if (line.find("Date :") != string::npos)
        {
            currentDate = line.substr(line.find(":") + 2);
            currentDate.erase(0, currentDate.find_first_not_of(" "));
            dateCount[currentDate]++;
        }
        if (line.find("Tickets :") != string::npos && !currentDate.empty())
        { 
            int seatCount = stod(line.substr(line.find(":") + 1));
            ticketCount[currentDate] += seatCount;
        }
        else if (line.find("Total Price :") != string::npos)
        {
            string amountStr = line.substr(line.find(":") + 1);
            amountStr.erase(0, amountStr.find_first_not_of(" "));
            try
            {
                lastTotal = stod(amountStr);
                if (!currentDate.empty())
                {
                    dateEarnings[currentDate] += lastTotal;
                }
            }
            catch (...)
            {
                cerr << " Invalid Total Price format.\n";
            }
        }
    }
    file.close();

    string searchDate;
    cout << "\nEnter date to see summary (e.g., 29/06/2025): ";
    getline(cin, searchDate);

    if (dateCount.find(searchDate) != dateCount.end())
    {
        cout << "\n--- Date-wise Booking Summary ---\n";
        cout << " Date: " << searchDate << "\n";
        cout << " Tickets Booked : " << ticketCount[searchDate] << "\n";
        cout << " Total Earnings  : " << fixed << setprecision(2) << dateEarnings[searchDate] << " INR\n";
        cout << "--------------------------\n";
    }
    else
    {
        cout << "\n No bookings found on " << searchDate << ".\n";
    }
}

void Admin::editAdvertisementTimes(vector<Movie> &movies)
{
    cout << "\n--- Edit Advertisement Times ---\n";
    for (int i = 0; i < movies.size(); ++i)
    {
        cout << i + 1 << ". " << movies[i].getName() << "\n";
    }

    int choice;
    cout << "Select a movie to edit ads for (1-" << movies.size() << "): ";
    cin >> choice;
    cin.ignore();

    if (choice < 1 || choice > movies.size())
    {
        cout << "Invalid choice.\n";
    }
    else
    {
        vector<string> startTimes(5), breakTimes(5);

        cout << "Enter 5 START ad times:\n";
        for (int i = 0; i < 5; ++i)
        {
            cout << "Start Slot " << (i + 1) << ": ";
            getline(cin, startTimes[i]);
        }

        cout << "Enter 5 BREAK ad times:\n";
        for (int i = 0; i < 5; ++i)
        {
            cout << "Break Slot " << (i + 1) << ": ";
            getline(cin, breakTimes[i]);
        }

        AdManager::saveAdTimes("advertisement_times.txt", movies[choice - 1].getName(), startTimes, breakTimes);
    }
}

void Admin::editAdvertisementPrices(vector<Movie> &movies)
{
    cout << "\n--- Edit Advertisement Prices ---\n";

    for (int i = 0; i < movies.size(); ++i)
    {
        cout << i + 1 << ". " << movies[i].getName() << "\n";
    }

    int choice;
    cout << "Select a movie to edit ad prices for (1-" << movies.size() << "): ";
    cin >> choice;
    cin.ignore();

    if (choice < 1 || choice > movies.size())
    {
        cout << "Invalid choice.\n";
        return;
    }

    string newAdPrices[5];
    string slotLabels[5] = {
        "START ad price slot 1",
        "BREAK ad price slot 2",
        "BREAK ad price slot 3",
        "BREAK ad price slot 4",
        "BREAK ad price slot 5"};

    for (int i = 0; i < 5; ++i)
    {
        cout << "Enter " << slotLabels[i] << " for \"" << movies[choice - 1].getName() << "\": ";
        getline(cin, newAdPrices[i]);
    }

    cout << " Advertisement prices updated for " << movies[choice - 1].getName() << "\n";
}

void Admin::showAdEarnings()
{
    ifstream inFile("ADBooking_details.txt");
    string line;
    float totalAdEarnings = 0.0f;

    while (getline(inFile, line))
    {
        if (line.find("Ad Price:") != string::npos)
        {
            string priceStr = line.substr(line.find(":") + 1);
            try
            {
                totalAdEarnings += stof(priceStr);
            }
            catch (...)
            {
                cerr << "Warning: Invalid price entry: " << priceStr << endl;
            }
        }
    }

    cout << "\nTotal Advertisement Earnings: " << totalAdEarnings << " INR\n";
}
